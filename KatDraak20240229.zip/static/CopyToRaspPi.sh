#!/bin/bash

# SCP command to copy folder to Raspberry Pi
scp -r /Users/marinus/Documents/repos/KatDraak root@homeassistant:~/repos
