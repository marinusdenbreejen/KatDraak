# Todo lijst


### To-Do List

- [x] Vervang draken door honden
- [x] zorg dat de overzicht pagina niet inzoomed, en de kaarten onder elkaar staan
- [x] De kaarten moeten even hoog zijn 
- [x] Timer moet gereset kunnen worden
- [x] getallen op wijzerplaat netjes verdelen: 
    - 0 - 5 min: onder 5 min de aanwijzing in seconden
    - 5 - 15 min, aantal minuten is aantal getallen
    - boven 15: altijd 10 streepjes
- [x] Tijd die over is, boven de wijzerplaat in notatie min:sec
- [x] app icon
- [ ] timer geluid
- [ ] timer op alle devices gelijk

## Conclusion or Final Thoughts

Wrap up your document with a conclusion or some final thoughts. This is a good place to summarize the document's key points or to provide a call to action.
